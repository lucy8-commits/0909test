# 이서원 QA/QC 포트폴리오 초안

## 실행 방법

`dist/index.html`을 브라우저에서 열면 별도 설치 없이 실행됩니다.

## 파일 구성

- `dist/index.html`: 페이지 구조와 콘텐츠
- `dist/styles.css`: 반응형 레이아웃과 디자인
- `dist/script.js`: 모바일 메뉴, 스크롤 메뉴 강조, 이메일 버튼

## 이메일 설정

`dist/script.js` 파일 상단의 `CONTACT_EMAIL`에 실제 이메일 주소를 입력하세요.

```js
const CONTACT_EMAIL = "your-email@example.com";
```

## 콘텐츠 순서

Home → 학력 → 아르바이트 경험 → 대외활동·동아리 → 자격·교육 → Contact

## 디자인 체계

- IBM Plex Sans 중심의 타이포그래피
- 흰색·연회색 표면과 IBM Blue 단일 포인트 색상
- 모서리가 각진 버튼과 카드, 1px 구분선
- 16열 데스크톱 그리드와 반응형 카드 배치
